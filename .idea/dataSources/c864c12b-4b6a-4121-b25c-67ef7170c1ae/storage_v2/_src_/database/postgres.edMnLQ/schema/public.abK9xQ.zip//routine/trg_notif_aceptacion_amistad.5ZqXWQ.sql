create function trg_notif_aceptacion_amistad() returns trigger
    language plpgsql
as
$$
DECLARE
    notif_id INT;
BEGIN
    IF OLD.estado = 'pendiente' AND NEW.estado = 'aceptada' THEN
        INSERT INTO Notificaciones DEFAULT VALUES
        RETURNING id_notificaciones INTO notif_id;

        INSERT INTO Notificacion_amistad(
            nombre_usuario_origen,
            nombre_usuario_destino,
            tipo,
            id_notificacion
        )
        VALUES (
            NEW.nombre_usuario_2,  -- quien acepta
            NEW.nombre_usuario_1,  -- quien recibe confirmación
            'aceptada',
            notif_id
        );
    END IF;

    RETURN NEW;
END;
$$;

alter function trg_notif_aceptacion_amistad() owner to admin_user;

