create function trg_sync_amistad_desde_notif() returns trigger
    language plpgsql
as
$$
BEGIN

    IF OLD.tipo = 'pendiente' AND NEW.tipo = 'aceptada' THEN

        UPDATE Amistades
        SET estado = 'aceptada'
        WHERE
            (nombre_usuario_1 = NEW.nombre_usuario_origen
             AND nombre_usuario_2 = NEW.nombre_usuario_destino)
        OR
            (nombre_usuario_1 = NEW.nombre_usuario_destino
             AND nombre_usuario_2 = NEW.nombre_usuario_origen);

    END IF;

    RETURN NEW;
END;
$$;

alter function trg_sync_amistad_desde_notif() owner to admin_user;

