create function insertar_publicacion_video_func() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO Publicaciones (id_publicacion, nombre_usuario, nombre_grupo)
    VALUES (NEW.id_publicacion, NEW.nombre_usuario, NEW.nombre_grupo);
    RETURN NEW;
END;
$$;

alter function insertar_publicacion_video_func() owner to admin_user;

