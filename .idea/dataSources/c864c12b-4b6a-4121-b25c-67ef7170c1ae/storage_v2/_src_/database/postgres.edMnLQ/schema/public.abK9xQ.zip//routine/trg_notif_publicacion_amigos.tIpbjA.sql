create function trg_notif_publicacion_amigos() returns trigger
    language plpgsql
as
$$
DECLARE
    notif_id INT;
    AMIGO RECORD;
BEGIN
    FOR amigo IN
        SELECT
            CASE
                WHEN a.nombre_usuario_1 = NEW.nombre_usuario THEN a.nombre_usuario_2
                ELSE a.nombre_usuario_1
            END AS nombre_amigo
        FROM Amistades a
        WHERE (a.nombre_usuario_1 = NEW.nombre_usuario OR a.nombre_usuario_2 = NEW.nombre_usuario)
          AND a.estado = 'aceptada'
    LOOP
        INSERT INTO Notificaciones DEFAULT VALUES
        RETURNING id_notificaciones INTO notif_id;

        INSERT INTO Notificacion_publicacion(
            nombre_usuario_origen,
            nombre_usuario_destino,
            tipo,
            id_notificacion
        )
        VALUES (
            NEW.nombre_usuario,
            amigo.nombre_amigo,
            'nueva_publicacion_amigo',
            notif_id
        );
    END LOOP;

    RETURN NEW;
END;
$$;

alter function trg_notif_publicacion_amigos() owner to admin_user;

