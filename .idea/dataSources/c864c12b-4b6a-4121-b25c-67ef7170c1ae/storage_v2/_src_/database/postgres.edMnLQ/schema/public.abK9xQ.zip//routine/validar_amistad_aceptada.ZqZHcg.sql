create function validar_amistad_aceptada() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.estado = 'aceptada' THEN
        IF NOT EXISTS (
            SELECT 1
            FROM Notificacion_amistad na
            WHERE na.tipo = 'pendiente'
              AND (
                  (na.nombre_usuario_origen = NEW.nombre_usuario_1 AND na.nombre_usuario_destino = NEW.nombre_usuario_2)
                  OR
                  (na.nombre_usuario_origen = NEW.nombre_usuario_2 AND na.nombre_usuario_destino = NEW.nombre_usuario_1)
              )
        ) THEN
            RAISE EXCEPTION 'No se puede aceptar amistad sin solicitud previa';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function validar_amistad_aceptada() owner to admin_user;

