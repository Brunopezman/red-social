create function eliminar_publicacion_func() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM Publicaciones
    WHERE id_publicacion = OLD.id_publicacion;
    RETURN OLD;
END;
$$;

alter function eliminar_publicacion_func() owner to admin_user;

