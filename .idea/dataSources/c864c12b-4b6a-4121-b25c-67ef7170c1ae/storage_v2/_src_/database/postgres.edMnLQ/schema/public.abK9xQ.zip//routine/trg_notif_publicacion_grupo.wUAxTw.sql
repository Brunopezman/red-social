create function trg_notif_publicacion_grupo() returns trigger
    language plpgsql
as
$$
DECLARE
    notif_id INT;
    miembro RECORD;
BEGIN
    IF NEW.nombre_grupo IS NOT NULL THEN
        FOR miembro IN
            SELECT ug.nombre_usuario
            FROM Usuarios_Grupos ug
            WHERE ug.nombre_grupo = NEW.nombre_grupo
              AND ug.nombre_usuario <> NEW.nombre_usuario
        LOOP
            INSERT INTO Notificaciones DEFAULT VALUES
            RETURNING id_notificaciones INTO notif_id;

            INSERT INTO Notificacion_publicacion(
                nombre_usuario_origen,
                nombre_usuario_destino,
                tipo,
                id_notificacion
            )
            VALUES (
                NEW.nombre_usuario,
                miembro.nombre_usuario,
                'nueva_publicacion_grupo',
                notif_id
            );
        END LOOP;
    END IF;

    RETURN NEW;
END;
$$;

alter function trg_notif_publicacion_grupo() owner to admin_user;

